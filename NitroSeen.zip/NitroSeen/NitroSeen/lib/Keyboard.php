﻿<?php
 
	class keyboard
	{
		public $buttons = [
        'help'                          => '⚠️ Yordam',
        'getPost'                       => 'Content Tarkibni yuborish',
        'managePost'                    => '🗂 Kontentni boshqarish',
        'refresh'                       => 'Yangilash',
        'manageAdmin'                   => 'Min Admin menejmenti',
        'manageChannel'                 => 'Kanal kanallarni boshqarish',
        'addChannel'                    => 'Kanal Kanal qoshish',
        'listChannel'                   => '📣 Kanallar royxati',
        'delChannel'                    => 'Kanallarni ochirish',
        'setting'                       => '⚙️ Sozlamalar',
        'endPost'                       => '🔚 Oxiri',
        'stats'                         => '📊 Statistika',
        'addAdmin'                      => 'Admin qoshish',
        'addSignature'                  => 'Maxsus imzo',
        'listAdmin'                     => 'Admin Adminlar royxati',
        'delAdmin'                      => 'Admin ochirish',
        'preview'                       => '👁 Korib chiqish',
        'sendUrgent'                    => '📮 Tez yuborish',
        'edit'                          => 'Tahrirlash',
        'delete'                        => '❌ Navbatdan olib tashlash ',
        'delPost'                       => 'Kanaldan olib tashlash',
        'permissionAdmin'               => 'Muallifi ruxsat berilgan fayllar',
        'countPost'                     => '📑 Yozuvlar soni',
        'watermarkPhoto'                => '🖼 Suv belgisi tasvirlari',
        'timeSend'                      => 'Vakolatli yuborish vaqti',
        'previewLink'                   => 'Havolani oldindan korish',
        'intervalPostSend'              => 'Ersol Post vaqt oraligi',
        'replaceID'                     => 'ID identifikatorini almashtirish',
        'orderPost'                     => '🔀 Tarkibni yuborish ketma -ketligi',
        'notification'                  => 'Foydalanuvchining xabarnomasi',
        'addSign'                       => 'Avtomatik imzo',
        'yes'                           => 'Ha Ha',
        'no'                            => 'Yoq Yoq',
        '1min'                          => 'Har 1 daqiqada',
        '5min'                          => 'Har 5 daqiqada',
        '15min'                         => 'Har 15 daqiqada',
        '30min'                         => 'Har 30 daqiqada',
        '45min'                         => 'Har 45 daqiqada',
        '1hour'                         => 'Har 1 soatda',
        '2hour'                         => 'Har 2 soatda',
        '3hour'                         => 'Har 3 soatda',
        '4hour'                         => 'Har 4 soatda',
        '5hour'                         => 'Har 5 soatda',
        '6hour'                         => 'Har 6 soatda',
        '7hour'                         => 'Har 7 soatda',
        '8hour'                         => 'Har 8 soatda',
        '9hour'                         => 'Har 9 soatda',
        '10hour'                        => 'Har 10 soatda',
        '11hour'                        => 'Har 11 soatda',
        '12hour'                        => 'Har 12 soatda',
        'deleteCronJob'                 => 'Vaqt oraligini yoq qiling',
        'delEmoji'                      => 'Em emodini ochirish',
        'delHashtag'                    => 'Hashtagni ochirish',
        'delLink'                       => 'Links Havolalarni ochirish',
        'forward'                       => '↗️ Oldinga rejim',
        'id'                            => 'IDni ochirish',
        'random'                        => 'tasodifan',
        'new'                           => 'Yangi kontent',
        'old'                           => 'Eski tarkib',
        'endPost'                       => '🔚 Oxiri',
        'go_back'                       => '➡️ Qaytish'
		];
		
		
		public function key_start()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['getPost'] . '"
			],
			[
			"' . $this->buttons['setting'] . '",
			"' . $this->buttons['managePost'] . '"
			],
			[
			"' . $this->buttons['manageChannel'] . '",
			"' . $this->buttons['manageAdmin'] . '"
			],
			[
			"' . $this->buttons['help'] . '",
			"' . $this->buttons['stats'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true 
			}
			}';
		}
		
		
		public function key_manageAdmin()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['addAdmin'] . '",
			"' . $this->buttons['listAdmin'] . '"
			],
			[
			"' . $this->buttons['delAdmin'] . '",
			"' . $this->buttons['permissionAdmin'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_manageChannel()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['addChannel'] . '",
			"' . $this->buttons['listChannel'] . '"
			],
			[
			"' . $this->buttons['addSignature'] . '",
			"' . $this->buttons['delChannel'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_setting()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['countPost'] . '",
			"' . $this->buttons['intervalPostSend'] . '"
			],
			[
			"' . $this->buttons['replaceID'] . '",
			"' . $this->buttons['watermarkPhoto'] . '"
			],
			[
			"' . $this->buttons['timeSend'] . '",
			"' . $this->buttons['previewLink'] . '"
			],
			[
			"' . $this->buttons['notification'] . '",
			"' . $this->buttons['orderPost'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '",
			"' . $this->buttons['addSign'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_confirm()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['no'] . '",
			"' . $this->buttons['yes'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_order()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['new'] . '",
			"' . $this->buttons['old'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '",
			"' . $this->buttons['random'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_interval()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['5min'] . '",
			"' . $this->buttons['1min'] . '"
			],
			[
			"' . $this->buttons['30min'] . '",
			"' . $this->buttons['15min'] . '"
			],
			[
			"' . $this->buttons['1hour'] . '",
			"' . $this->buttons['45min'] . '"
			],
			[
			"' . $this->buttons['3hour'] . '",
			"' . $this->buttons['2hour'] . '"
			],
			[
			"' . $this->buttons['5hour'] . '",
			"' . $this->buttons['4hour'] . '"
			],
			[
			"' . $this->buttons['7hour'] . '",
			"' . $this->buttons['6hour'] . '"
			],
			[
			"' . $this->buttons['9hour'] . '",
			"' . $this->buttons['8hour'] . '"
			],
			[
			"' . $this->buttons['11hour'] . '",
			"' . $this->buttons['10hour'] . '"
			],
			[
			"' . $this->buttons['deleteCronJob'] . '",
			"' . $this->buttons['12hour'] . '"
			],
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function key_stats()
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['refresh'],'callback_data'=>"stats-refresh"]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function key_post($id,$msgID)
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['sendUrgent'],'callback_data'=>"send-".$id."-".$msgID],
			['text'=>$this->buttons['preview'],'callback_data'=>"view-".$id."-".$msgID]
			],
			[
			['text'=>$this->buttons['delete'],'callback_data'=>"del-".$id."-".$msgID],
			['text'=>$this->buttons['edit'],'callback_data'=>"edit-".$id."-".$msgID]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function key_del($msgID,$id)
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['delPost'],'callback_data'=>"deletePost-".$msgID."-".$id]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function key_edit($id,$msgID)
		{
			$keyboard = array(
			'inline_keyboard' => array(
			[
			['text'=>$this->buttons['forward'],'callback_data'=>"forward-".$id."-".$msgID],
			['text'=>$this->buttons['delEmoji'],'callback_data'=>"delEmoji-".$id."-".$msgID]
			],
			[
			['text'=>$this->buttons['delHashtag'],'callback_data'=>"delHashtag-".$id."-".$msgID],
			['text'=>$this->buttons['delLink'],'callback_data'=>"delLink-".$id."-".$msgID]
			],
			[
			['text'=>$this->buttons['go_back'],'callback_data'=>"back-".$id."-".$msgID],
			['text'=>$this->buttons['id'],'callback_data'=>"id-".$id."-".$msgID]
			]
			)
			);
			return  json_encode($keyboard);
		}
		
		
		public function go_back()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['go_back'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
		
		
		public function go_back_end()
		{
			return  '{
			"keyboard": [
			[
			"' . $this->buttons['go_back'] . '",
			"' . $this->buttons['endPost'] . '"
			]
			],
			"resize_keyboard" : true,
			"ForceReply":{
			"force_reply" : true
			}
			}';
		}
	}