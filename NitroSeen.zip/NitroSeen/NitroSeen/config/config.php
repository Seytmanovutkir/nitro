<?php
class config{

	public $bot_id             = '1451101893:AAEtx1PS_NV3CtArocVSU9-fqGdEJwgLliA'; // توکن ربات
	public $path               = 'https://seenservice.ir/Bots/Vardast/'; // آدرس هاست محل پوشه
	public $database_host      = 'localhost'; // دست نزنید
	public $database_name      = 'cp29693_vardast'; // نام دیتابیس
	public $database_username  = 'cp29693_vardast'; // یوزرنیم
	public $database_password  = 'wUtq&yl+gZnw'; // پسورد
	public $bot_Username       = 'prasmotrbot_robot'; // ایدی ربات بدون @
	public $admin_list         = array(854021271,1489956324); // ادمین ها بترتیب
	public $CHANNEL_ID         = '@phpkodlar_baza'; // ایدی کانال
	public $CHANNEL_LINK       = 'http://t.me/phpkodlar_baza'; // لینک کانال
	public $version            = '2.1'; // دست نزنید
	
}

/*
این سورس
توسط : @DevHamidReza
در کانال : @souresphp
باگ گیری شده است.
*/