<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update("member", [ 'last_query' => 'notification' ],["id" => $data->user_id]);
			
			if(file_get_contents("config/notification.txt")==1)
			{
				$statusOld=$keyboard->buttons['yes'];
			}
			else
			{
				$statusOld=$keyboard->buttons['no'];
			}
			
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'text' => "زمانی که یک مطلب توسط این ربات به کانال تلگرامی شما ارسال می‌شود، کاربر یک نوتیفیکیشن دریافت می‌کند که متوجه می‌شود مطلب جدیدی در کانال شما درج شده است. اما شما می‌توانید این هشدار را خاموش کنید و تنها در مواقعی که مطلب ضروری و فوری است، آن را روشن کنید."."\n\n"."❓ وضعیت فعلی : ".$statusOld,
			'reply_markup' => $keyboard->key_confirm()
			]);
		}
		elseif ( $constants->last_message == 'notification' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_setting()
				]);
			} 
			else 
			{
				if($data->text==$keyboard->buttons['yes'] or $data->text==$keyboard->buttons['no'])
				{
					$database->update("member", [ 'last_query' => null ],["id" => $data->user_id]);
					
					if($data->text==$keyboard->buttons['yes'])
					{
						$status=1;
					}
					else
					{
						$status=0;
					}
					
					file_put_contents("config/notification.txt",$status);
					
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'parse_mode' => 'Markdown',
					'text' => "✅ وضعیت جدید باموفقیت ثبت شد.",
					'reply_markup' => $keyboard->key_setting()
					]);
				}
				else
				{
					$database->update("member", [ 'last_query' => 'notification' ],["id" => $data->user_id]);
					
					if(file_get_contents("config/notification.txt")==1)
					{
						$statusOld=$keyboard->buttons['yes'];
					}
					else
					{
						$statusOld=$keyboard->buttons['no'];
					}
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ یکی از گزینه های زیر را می بایست انتخاب نمایید."."\n\n"."زمانی که یک مطلب توسط این ربات به کانال تلگرامی شما ارسال می‌شود، کاربر یک نوتیفیکیشن دریافت می‌کند که متوجه می‌شود مطلب جدیدی در کانال شما درج شده است. اما شما می‌توانید این هشدار را خاموش کنید و تنها در مواقعی که مطلب ضروری و فوری است، آن را روشن کنید."."\n\n"."❓ وضعیت فعلی : ".$statusOld,
					'reply_markup' => $keyboard->key_confirm()
					]);
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
	/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/
