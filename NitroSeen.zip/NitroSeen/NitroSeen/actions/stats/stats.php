<?php
 
	require_once dirname(__FILE__) . '/../../autoload.php';
	
	function JalaliAgo($jalaliDate, $beforeDays) {
		list($y, $m, $d) = explode('/', $jalaliDate);
		$ts = jmktime(0, 0, 0, $m, $d, $y);
		for($i = 0; $i < $beforeDays; $i++) {
			$ts -= 86400;
		}
		return jdate('Y/n/d', $ts);
	}
	
	if(in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id]))
	{
		$count          = $database->count("list");
		$countDeactive  = $database->count("list", ["status" => -1]);
		$countActive    = $database->count("list", ["status" => 0]);
		$readyForSend   = $database->count("list", ["status" => 1]);
		if ($data->callback_query)
		{
			if($data->text=="stats-refresh")
			{
				$telegram->editMessageText([
				'chat_id' => $data->chat_id,
				'message_id' => $data->message_id,
				'parse_mode' => 'Markdown',
				'text' => 
				'📊 ' . 'Post Statistika'."\n\n".
				'📋 ' . 'Jami : `' . $count . '`'."\n".
				'📬'. 'Xabar yuborildi : `' . $readyForSend . '`'."\n".
				'🕐'. Tayyor postlar  yuboring : `' . $countActive . '`'."\n".
				'🚮 '. Xabarlarni bekor qilish : `' . $countDeactive . '`',
				'reply_markup' => $keyboard->key_stats()
				]);
				
				$telegram->answerCallbackQuery([
				'callback_query_id' => $data->callback_query_id,
				'show_alert' => false,
				'text'=>"Robotlar statistikasi yangilandi."
				]);
			}
		}
		else
		{			
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'parse_mode' => 'Markdown',
			'text' => 
			'📊 ' . 'Post Statistika'."\n\n".
				'📋 ' . 'Jami : `' . $count . '`'."\n".
				'📬'. 'Xabar yuborildi : `' . $readyForSend . '`'."\n".
				'🕐'. Tayyor postlar  yuboring : `' . $countActive . '`'."\n".
				'🚮 '. Xabarlarni bekor qilish : `' . $countDeactive . '`',
			'reply_markup' => $keyboard->key_stats()
			]);
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "Kechirasiz, sizda bu bo'limga kirishga ruxsat yo'q.",
		"parse_mode" =>"HTML"
		]);
	}
 