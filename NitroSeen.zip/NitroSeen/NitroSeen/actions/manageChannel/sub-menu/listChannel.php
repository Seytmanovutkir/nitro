<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	$database->update("member", [ 'last_query' => null ], [ 'id' => $data->user_id ]);
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
		$channel='';
		$i=1;
		$catInfo = $database->query("SELECT channel FROM `channel` order by channel ASC");
		while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
		{
			$channel .= $i." - <a href='https://t.me/".$item_type['channel']."'>".$item_type['channel']."</a>\n\n";
			$i++;
		}
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' => ($channel!="" ? "لیست کانال ها:\n\n".$channel:"کانالی ثبت نشده است."),
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_manageChannel()
		]);
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}	