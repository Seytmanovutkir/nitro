<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update('member', ['last_query' => 'addSignature'], ['id' => $data->user_id]);
			
			$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
			while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
			{
				$keys[] = $item_type['channel'];
			}
			
			$count=count($keys);
			if($count%2==0)
			{
				array_push($keys,"",$keyboard->buttons['go_back']);
			}
			else
			{
				array_push($keys,$keyboard->buttons['go_back']);
			}
			$j=0;
			$i=1;
			for($d=0;$d<=$count/2;$d++)
			{
				$options[]=array($keys[$i],$keys[$j]);
				$j=$j+2;
				$i=$i+2;
			}
			
			if( $options[0][0] !=null && $options[0][1] !=null )
			{
				$keyboard = Array(
				'keyboard' => $options ,
				'resize_keyboard' => true ,
				'one_time_keyboard' => false ,
				'selective' => true
				);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
				'reply_markup' => json_encode($keyboard)
				]);
			}
			else
			{
				$database->update('member', ['last_query' => null,'last_request' =>null], ['id' => $data->user_id]);	
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
				'reply_markup' => $keyboard->key_manageChannel()
				]);
			}
		} 
		elseif ( $constants->last_message == 'addSignature' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", ['last_query' => null,'last_request' =>null], ['id' => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_manageChannel()
				]);
			} 
			else if($database->has("channel", ["channel" => $data->text]))
			{
				$database->update("member", ['last_query' => 'submitSignature','last_request' => $data->text], ['id' => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->chat_id,
				'parse_mode' => 'Markdown', 
				'text' => "📝 لطفا امضا مورد نظر خود را ارسال نمایید:",
				'reply_markup' => $keyboard->go_back()
				]);
			}
			else
			{
				$database->update('member', ['last_query' => 'addSignature'], ['id' => $data->user_id]);	
				
				$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					$keys[] = $item_type['channel'];
				}
				
				$count=count($keys);
				if($count%2==0)
				{
					array_push($keys,"",$keyboard->buttons['go_back']);
				}
				else
				{
					array_push($keys,$keyboard->buttons['go_back']);
				}
				$j=0;
				$i=1;
				for($d=0;$d<=$count/2;$d++)
				{
					$options[]=array($keys[$i],$keys[$j]);
					$j=$j+2;
					$i=$i+2;
				}
				
				if( $options[0][0] !=null && $options[0][1] !=null )
				{
					$keyboard = Array(
					'keyboard' => $options ,
					'resize_keyboard' => true ,
					'one_time_keyboard' => false ,
					'selective' => true
					);
					
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "🚫 از دکمه های زیر استفاده کنید."."\n\n"."✅ لطفا کانال مورد نظر خود را انتخاب نمایید:",
					'reply_markup' => json_encode($keyboard)
					]);
				}
				else
				{
					$database->update('member', ['last_query' => null,'last_request' =>null], ['id' => $data->user_id]);	
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "⚠️ متاسفانه در حال حاضر کانالی وجود ندارد.",
					'reply_markup' => $keyboard->key_manageChannel()
					]);
				}
			}
		} 
		elseif ( $constants->last_message == 'submitSignature' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", ['last_query' => null,'last_request' =>null], ['id' => $data->user_id]);
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "گزینه مورد نظر را انتخاب نمایید:",
				'reply_markup' => $keyboard->key_manageChannel()
				]);
			} 
			else
			{
				$database->update("member", ['last_query' => null], ['id' => $data->user_id]);
				$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
				$database->update("channel", ['signature' => $data->text], ['channel' => $last_request[0]['last_request']]);
				$telegram->sendMessage([
				'chat_id' => $data->chat_id,
				'parse_mode' => 'Markdown', 
				'text' => "✅ امضا کانال @".$last_request[0]['last_request']." باموفقیت ثبت گردید.",
				'reply_markup' => $keyboard->key_manageChannel()
				]);
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML",
		'reply_markup' => $keyboard->key_start()
		]);
	}
