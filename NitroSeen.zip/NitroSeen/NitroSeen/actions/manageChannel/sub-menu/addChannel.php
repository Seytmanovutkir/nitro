<?php
	require_once dirname(__FILE__) . '/../../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list))
	{
		if ( $constants->last_message === null ) 
		{
			$database->update("member", [ 'last_query' => 'addChannel' ], [ 'id' => $data->user_id ]);
			$telegram->sendMessage([
			'chat_id' => $data->chat_id,
			'text' => "✅ لطفا شناسه کانال خود را بدون @ ارسال نمایید:",
			'reply_markup' => $keyboard->go_back()
			]);
		}
		elseif ( $constants->last_message == 'addChannel' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ], [ 'id' => $data->user_id ]);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "لطفا یک گزینه را انتخاب کنید:",
				'reply_markup' => $keyboard->key_manageChannel()
				]);
			} 
			else 
			{
				if($data->text)
				{
					$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
					$channelID=str_replace("@","",$data->text);
					if($database->has("channel", ["channel" => $channelID]))
					{
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'text' => "⚠️ این کانال قبلا ثبت شده است.",
						'reply_markup' => $keyboard->key_manageChannel()
						]);
					}
					else
					{
						$database->insert("channel", [
						"channel" => $channelID,
						"status" => 1
						]);
						
						$checkpm=file_get_contents("config/checkpm.txt");
						$checkpm=str_replace("**CHANNEL**",$channelID,$checkpm);
						
						mkdir("config/interval/".$channelID);
						file_put_contents("config/interval/".$channelID."/interval.txt","");
						file_put_contents("config/interval/".$channelID."/lastinterval.txt","");
						file_put_contents("config/interval/".$channelID."/checkpm.php",$checkpm);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'text' => "✅ کانال @".$channelID." باموفقیت ثبت شد!"."\n"."⚠️ توجه کنید که ربات حتما در کانال ثبت شده ادمین باشد."."\n"."⚠️ از بخش تنظیمات فاصله زمانی ارسال را حتما تعیین نمایید."."\n"."🔹 بخش مورد نظر خود را انتخاب نمایید:",
						'reply_markup' => $keyboard->key_manageChannel()
						]);
					}
				}
				else
				{
					$database->update("member", [ 'last_query' => 'addChannel' ], [ 'id' => $data->user_id ]);
					$telegram->sendMessage([
					'chat_id' => $data->chat_id,
					'text' => "⚠️ لطفا شناسه کانال را بدون @ ارسال نمایید:",
					'reply_markup' => $keyboard->go_back()
					]);
				}
			}
		}
	}	
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "⚠️ متاسفانه شما اجازه دسترسی به این بخش را ندارید.",
		"parse_mode" =>"HTML"
		]);
	}
