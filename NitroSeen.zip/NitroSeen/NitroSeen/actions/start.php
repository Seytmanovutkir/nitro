<?php
/*
کانال سورس خونه ! پر از سورس هاي ربات هاي تلگرامي !
لطفا در کانال ما عضو شويد 
@source_home
https://t.me/source_home
*/
	require_once dirname(__FILE__).'/../autoload.php';
	
	$database->update("member", ['status' => 1, 'last_query' => null, 'last_request' => null], ["id" => $data->user_id]);
	
	if($data->text=="/start")
	{
		$telegram->sendMessage([
		'chat_id' => $data->chat_id,
		'parse_mode' => 'Markdown',
		'disable_web_page_preview' => 'true',
		'text' => "O'zingiz xohlagan bo'limni tanlang:",
		'reply_markup' => $keyboard->key_start() 
		]);
	} 
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->chat_id,
		'parse_mode' => 'Markdown',
		'disable_web_page_preview' => 'true',
		'text' => "O'zingiz xohlagan bo'limni tanlang:",
		'reply_markup' => $keyboard->key_start() 
		]);
	}