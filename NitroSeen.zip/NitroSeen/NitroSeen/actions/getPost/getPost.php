<?php
 
	require_once dirname(__FILE__) . '/../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id]))
	{
		if ( $constants->last_message === null ) 
		{	
			$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
			
			$database->update('member', ['last_query' => 'channel'], ['id' => $data->user_id]);	
			while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
			{
				$keys[] = $item_type['channel'];
			}
			
			$count=count($keys);
			if($count%2==0)
			{
				array_push($keys,"",$keyboard->buttons['go_back']);
			}
			else
			{
				array_push($keys,$keyboard->buttons['go_back']);
			}
			$j=0;
			$i=1;
			for($d=0;$d<=$count/2;$d++)
			{
				$options[]=array($keys[$i],$keys[$j]);
				$j=$j+2;
				$i=$i+2;
			}
			
			if( $options[0][0] !=null && $options[0][1] !=null )
			{
				$keyboard = Array(
				'keyboard' => $options ,
				'resize_keyboard' => true ,
				'one_time_keyboard' => false ,
				'selective' => true
				);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "F Iltimos, kerakli kanalni tanlang:",
				'reply_markup' => json_encode($keyboard)
				]);
			}
			else
			{
				$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "Afsuski, hozircha kanal yo'q.",
				'reply_markup' => $keyboard->key_start()
				]);
			}
		}
		elseif ( $constants->last_message == 'getPost' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
				
				$database->update('member', ['last_query' => 'channel','last_request' => null], ['id' => $data->user_id]);	
				while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
				{
					$keys[] = $item_type['channel'];
				}
				
				$count=count($keys);
				if($count%2==0)
				{
					array_push($keys,"",$keyboard->buttons['go_back']);
				}
				else
				{
					array_push($keys,$keyboard->buttons['go_back']);
				}
				$j=0;
				$i=1;
				for($d=0;$d<=$count/2;$d++)
				{
					$options[]=array($keys[$i],$keys[$j]);
					$j=$j+2;
					$i=$i+2;
				}
				
				if( $options[0][0] !=null && $options[0][1] !=null )
				{
					$keyboard = Array(
					'keyboard' => $options ,
					'resize_keyboard' => true ,
					'one_time_keyboard' => false ,
					'selective' => true
					);
					
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "F Iltimos, kerakli kanalni tanlang:",
					'reply_markup' => json_encode($keyboard)
					]);
				}
				else
				{
					$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "Afsuski, hozircha kanal yo'q",
					'reply_markup' => $keyboard->key_start()
					]);
				}
			}
			else if ( $data->text == $keyboard->buttons['endPost'] ) 
			{
				$database->update('member', ['last_query' => null,'last_request' => null], ['id' => $data->user_id]);	
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "✅ O'zingizga kerakli bo'limni tanlang:",
				'reply_markup' => $keyboard->key_start()
				]);
			}
			else 
			{
				$database->update("member", ['last_query' => 'getPost'],["id" => $data->user_id]);
				
				if(isset($data->document))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(isset($data->caption))
						{
							if(file_get_contents("config/replaceID.txt")==1)
							{
								$text=str_replace("_", '', $data->caption);
								$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
							}
							else
							{
								$caption=$data->caption;
							}
							
							$list_id=$database->insert("list", [
							"file_id" => $data->document_file_id,
							'msg_id' => $data->message_id, 
							"caption" => $caption,
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						else
						{
							$list_id=$database->insert("list", [
							"file_id" => $data->document_file_id,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yxatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);				
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['file']=="1")
						{
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							if(isset($data->caption))
							{
								if(file_get_contents("config/replaceID.txt")==1)
								{
									$text=str_replace("_", '', $data->caption);
									$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
								}
								else
								{
									$caption=$data->caption;
								}
								
								$list_id=$database->insert("list", [
								"file_id" => $data->document_file_id,
								'msg_id' => $data->message_id, 
								"caption" => $caption,
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							else
							{
								$list_id=$database->insert("list", [
								"file_id" => $data->document_file_id,
								'msg_id' => $data->message_id, 
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yxatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);						
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->video))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(isset($data->caption))
						{
							if(file_get_contents("config/replaceID.txt")==1)
							{
								$text=str_replace("_", '', $data->caption);
								$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
							}
							else
							{
								$caption=$data->caption;
							}
							
							$list_id=$database->insert("list", [
							"video_id" => $data->video_file_id,
							'msg_id' => $data->message_id, 
							"caption" => $caption,
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						else
						{
							$list_id=$database->insert("list", [
							"video_id" => $data->video_file_id,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yxatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['video']=="1")
						{
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							if(isset($data->caption))
							{
								if(file_get_contents("config/replaceID.txt")==1)
								{
									$text=str_replace("_", '', $data->caption);
									$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
								}
								else
								{
									$caption=$data->caption;
								}
								
								$list_id=$database->insert("list", [
								"video_id" => $data->video_file_id,
								'msg_id' => $data->message_id, 
								"caption" => $caption,
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							else
							{
								$list_id=$database->insert("list", [
								"video_id" => $data->video_file_id,
								'msg_id' => $data->message_id, 
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yxatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->photo))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(isset($data->caption))
						{
							if(file_get_contents("config/replaceID.txt")==1)
							{
								$text=str_replace("_", '', $data->caption);
								$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
							}
							else
							{
								$caption=$data->caption;
							}
							
							$photo = $data->photo;
							foreach($photo as $pic)
							$pict = $pic['file_id'];
							$list_id=$database->insert("list", [
							"photo_id" => $pict,
							'msg_id' => $data->message_id, 
							"caption" => $caption,
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						else
						{
							$photo = $data->photo;
							foreach($photo as $pic)
							$pict = $pic['file_id'];
							$list_id=$database->insert("list", [
							"photo_id" => $pict,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);	
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['photo']=="1")
						{
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							if(isset($data->caption))
							{
								if(file_get_contents("config/replaceID.txt")==1)
								{
									$text=str_replace("_", '', $data->caption);
									$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
								}
								else
								{
									$caption=$data->caption;
								}
								
								$photo = $data->photo;
								foreach($photo as $pic)
								$pict = $pic['file_id'];
								$list_id=$database->insert("list", [
								"photo_id" => $pict,
								'msg_id' => $data->message_id, 
								"caption" => $caption,
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							else
							{
								$photo = $data->photo;
								foreach($photo as $pic)
								$pict = $pic['file_id'];
								$list_id=$database->insert("list", [
								"photo_id" => $pict,
								'msg_id' => $data->message_id, 
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);	
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->audio))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(isset($data->caption))
						{
							if(file_get_contents("config/replaceID.txt")==1)
							{
								$text=str_replace("_", '', $data->caption);
								$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
							}
							else
							{
								$caption=$data->caption;
							}
							
							$list_id=$database->insert("list", [
							"audio_id" => $data->audio_file_id,
							'msg_id' => $data->message_id, 
							"caption" => $caption,
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						else
						{
							$list_id=$database->insert("list", [
							"audio_id" => $data->audio_file_id,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['audio']=="1")
						{
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							if(isset($data->caption))
							{
								if(file_get_contents("config/replaceID.txt")==1)
								{
									$text=str_replace("_", '', $data->caption);
									$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
								}
								else
								{
									$caption=$data->caption;
								}
								
								$list_id=$database->insert("list", [
								"audio_id" => $data->audio_file_id,
								'msg_id' => $data->message_id, 
								"caption" => $caption,
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							else
							{
								$list_id=$database->insert("list", [
								"audio_id" => $data->audio_file_id,
								'msg_id' => $data->message_id, 
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqjyatli ro'yhatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->sticker))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						$list_id=$database->insert("list", [
						"sticker_id" => $data->sticker_file_id,
						'msg_id' => $data->message_id, 
						"ch_name" => $last_request[0]['last_request'],
						"admin_id" => $data->user_id,
						'date_created' => jdate("Y/n/d")
						]);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['sticker']=="1")
						{
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							$list_id=$database->insert("list", [
							"sticker_id" => $data->sticker_file_id,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->voice))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						if(isset($data->caption))
						{
							if(file_get_contents("config/replaceID.txt")==1)
							{
								$text=str_replace("_", '', $data->caption);
								$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
							}
							else
							{
								$caption=$data->caption;
							}
							
							$list_id=$database->insert("list", [
							"voice_id" => $data->voice_file_id,
							'msg_id' => $data->message_id, 
							"caption" => $caption,
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						else
						{
							$list_id=$database->insert("list", [
							"voice_id" => $data->voice_file_id,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
						}
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yhatdan o'tdi ",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['voice']=="1")
						{					
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							if(isset($data->caption))
							{
								if(file_get_contents("config/replaceID.txt")==1)
								{
									$text=str_replace("_", '', $data->caption);
									$caption=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
								}
								else
								{
									$caption=$data->caption;
								}
								
								$list_id=$database->insert("list", [
								"voice_id" => $data->voice_file_id,
								'msg_id' => $data->message_id, 
								"caption" => $caption,
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							else
							{
								$list_id=$database->insert("list", [
								"voice_id" => $data->voice_file_id,
								'msg_id' => $data->message_id, 
								"ch_name" => $last_request[0]['last_request'],
								"admin_id" => $data->user_id,
								'date_created' => jdate("Y/n/d")
								]);
							}
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->location))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						$list_id=$database->insert("list", [
						"location_long" => $data->longitude,
						"location_lat" => $data->latitude,
						'msg_id' => $data->message_id, 
						"ch_name" => $last_request[0]['last_request'],
						"admin_id" => $data->user_id,
						'date_created' => jdate("Y/n/d")
						]);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['location']=="1")
						{
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							$list_id=$database->insert("list", [
							"location_long" => $data->longitude,
							"location_lat" => $data->latitude,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else if(isset($data->text))
				{
					if(in_array($data->user_id, $auth->admin_list))
					{
						if(file_get_contents("config/replaceID.txt")==1)
						{
							$text=str_replace("_", '', $data->text);
							$textReplace=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
						}
						else
						{
							$textReplace=$data->text;
						}
						
						$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
						$list_id=$database->insert("list", [
						"caption" => $textReplace,
						'msg_id' => $data->message_id, 
						"ch_name" => $last_request[0]['last_request'],
						"admin_id" => $data->user_id,
						'date_created' => jdate("Y/n/d")
						]);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'reply_to_message_id' => $data->message_id, 
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
						'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
						]);
					}		
					else
					{
						$rows = $database->select('admin', '*', ["user" => $data->user_id]);
						if($rows[0]['text']=="1")
						{
							if(file_get_contents("config/replaceID.txt")==1)
							{
								$text=str_replace("_", '', $data->text);
								$textReplace=preg_replace("/@([\p{L}\p{Mn}]+)/u", "@".$last_request[0]['last_request'], $text);
							}
							else
							{
								$textReplace=$data->text;
							}
							
							$last_request = $database->select('member', ['last_request'], ['id' => $data->user_id]);
							$list_id=$database->insert("list", [
							"caption" => $textReplace,
							'msg_id' => $data->message_id, 
							"ch_name" => $last_request[0]['last_request'],
							"admin_id" => $data->user_id,
							'date_created' => jdate("Y/n/d")
							]);
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'reply_to_message_id' => $data->message_id, 
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => "Muvaffaqiyatli ro'yhatdan o'tdi",
							'reply_markup' => $keyboard->key_post($list_id,($data->message_id+1))
							]);
						}
						else
						{
							if($rows[0]['sticker']=="0"){ $stickerView="🚫";} else{ $stickerView="✅";}
							if($rows[0]['photo']=="0"){ $photoView="🚫";} else{ $photoView="✅";}
							if($rows[0]['video']=="0"){ $videoView="🚫";} else{ $videoView="✅";}
							if($rows[0]['voice']=="0"){ $voiceView="🚫";} else{ $voiceView="✅";}
							if($rows[0]['audio']=="0"){ $audioView="🚫";} else{ $audioView="✅";}
							if($rows[0]['file']=="0"){ $fileView="🚫";} else{ $fileView="✅";}
							if($rows[0]['text']=="0"){ $textView="🚫";} else{ $textView="✅";}
							if($rows[0]['location']=="0"){ $locationView="🚫";} else{ $locationView="✅";}
							
							$txt="Kechirasiz, sizga bu turdagi postlarni joylashtirishga ruxsat berilmagan. \ NYPosting uchun sizning maqomingiz: \ nStiker:".$stickerView."\ntasvir : ".$photoView."\nVideo : ".$videoView."\nOvoz : ".$voiceView."\nMusiqa : ".$audioView."\nFayl : ".$fileView."\nMatn : ".$textView."\nJoylashuv : ".$locationView."\nIltimos, xabaringizni qayta yuboring:\n";
							
							$telegram->sendMessage([
							'chat_id' => $data->user_id,
							'parse_mode' => 'Markdown', 
							'disable_web_page_preview' => 'true',
							'text' => $txt,
							'reply_markup' => $keyboard->go_back()
							]);
						}
					}
				}
				else
				{
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "⚠️ Xabarlarga ruxsat berilmaydi!",
					'reply_markup' => $keyboard->go_back()
					]);
				}
			}
		}
		
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "Kechirasiz, sizda bu bo'limga kirishga ruxsat yo'q.",
		"parse_mode" =>"HTML"
		]);
	}						
 