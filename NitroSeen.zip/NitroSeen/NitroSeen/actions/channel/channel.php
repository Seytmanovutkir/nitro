<?php
/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/
	require_once dirname(__FILE__) . '/../../autoload.php';
	
	if(in_array($data->user_id, $auth->admin_list) or $database->has("admin", ["user" => $data->user_id]))
	{
		if ( $constants->last_message === null ) 
		{		
			$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
			
			$database->update('member', ['last_query' => 'channel'], ['id' => $data->user_id]);	
			while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
			{
				$keys[] = $item_type['channel'];
			}
			
			$count=count($keys);
			if($count%2==0)
			{
				array_push($keys,"",$keyboard->buttons['go_back']);
			}
			else
			{
				array_push($keys,$keyboard->buttons['go_back']);
			}
			$j=0;
			$i=1;
			for($d=0;$d<=$count/2;$d++)
			{
				$options[]=array($keys[$i],$keys[$j]);
				$j=$j+2;
				$i=$i+2;
			}
			
			if( $options[0][0] !=null && $options[0][1] !=null )
			{
				$keyboard = Array(
				'keyboard' => $options ,
				'resize_keyboard' => true ,
				'one_time_keyboard' => false ,
				'selective' => true
				);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "F Iltimos, kerakli kanalni tanlang",
				'reply_markup' => json_encode($keyboard)
				]);
			}
			else
			{
				$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'parse_mode' => 'Markdown', 
				'disable_web_page_preview' => 'true',
				'text' => "Afsuski, hozircha kanal yo'q.",
				'reply_markup' => $keyboard->key_start()
				]);
			}
		}
		elseif ( $constants->last_message == 'channel' ) 
		{
			if ( $data->text == $keyboard->buttons['go_back'] ) 
			{
				$database->update("member", [ 'last_query' => null ], [ 'id' => $data->user_id ]);
				
				$telegram->sendMessage([
				'chat_id' => $data->user_id,
				'text' => "Kerakli variantni tanlang:",
				'reply_markup' => $keyboard->key_start()
				]);
			}
			else 
			{
				if($database->has("channel", ["channel" => $data->text]))
				{
					$database->update("member", ['last_query' => 'getPost','last_request' => $data->text], ['id' => $data->user_id]);
					
					$telegram->sendMessage([
					'chat_id' => $data->user_id,
					'parse_mode' => 'Markdown', 
					'disable_web_page_preview' => 'true',
					'text' => "🔸 Iltimos, tarkibingizni tartibda yuboring va nihoyat tugatish tugmachasini tanlang:",
					'reply_markup' => $keyboard->go_back_end()
					]);
				}
				else
				{
					$database->update('member', ['last_query' => 'channel'], ['id' => $data->user_id]);	
					
					$catInfo = $database->query("SELECT channel FROM `channel` where status=1 order by channel ASC");
					while($item_type=$catInfo->fetch(PDO::FETCH_ASSOC))
					{
						$keys[] = $item_type['channel'];
					}
					
					$count=count($keys);
					if($count%2==0)
					{
						array_push($keys,"",$keyboard->buttons['go_back']);
					}
					else
					{
						array_push($keys,$keyboard->buttons['go_back']);
					}
					$j=0;
					$i=1;
					for($d=0;$d<=$count/2;$d++)
					{
						$options[]=array($keys[$i],$keys[$j]);
						$j=$j+2;
						$i=$i+2;
					}
					
					if( $options[0][0] !=null && $options[0][1] !=null )
					{
						$keyboard = Array(
						'keyboard' => $options ,
						'resize_keyboard' => true ,
						'one_time_keyboard' => false ,
						'selective' => true
						);
						
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "✅ Iltimos, xohlagan kanalingizni eksponent sifatida tanlang",
						'reply_markup' => json_encode($keyboard)
						]);
					}
					else
					{
						$database->update('member', ['last_query' => null], ['id' => $data->user_id]);	
						$telegram->sendMessage([
						'chat_id' => $data->user_id,
						'parse_mode' => 'Markdown', 
						'disable_web_page_preview' => 'true',
						'text' => "Afsuski, hozircha kanal yo'q.",
						'reply_markup' => $keyboard->key_start()
						]);
					}
				}
			}
		}
	}
	else
	{
		$telegram->sendMessage([
		'chat_id' => $data->user_id,
		'text' =>  "Kechirasiz, sizda bu bo'limga kirishga ruxsat yo'q.",
		"parse_mode" =>"HTML"
		]);
	}
/*

📌 کانال ایلیا سورس
برای دریافت سورس های بیشتر به کانال ما سر بزنید :)
@Source_Eliya

*/